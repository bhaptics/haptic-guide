## GunsnStroy X bHaptics
### Getting Started
* https://github.com/bhaptics/TactUnrealEngine4/wiki/Getting-Started-(From-1.5.0)

### Project Structure
##### 1. Content/Haptic/ArmLeft|ArmRight|Vest|Head : Haptic patterns used in the sample project
##### 2. Content/Haptic/BhapticsHapticPatternList.uasset: Blueprint callable function list 

![image](https://user-images.githubusercontent.com/1837913/76304660-1830e580-6307-11ea-8e1f-ca2f4895a273.png)

##### 3. Content/Blueprints/SampleWidget.uasset: Sample UI Widget with buttons to show example usage of `BhapticsHapticPatternList`
* UI Layout 

![image](https://user-images.githubusercontent.com/1837913/76304826-60500800-6307-11ea-8757-b036f81e4071.png)

* Simple usage of calling functions

![image](https://user-images.githubusercontent.com/1837913/76304916-88d80200-6307-11ea-8df7-e8109df49a32.png)

* Example usage for getting Rotation Vest Feedback (Project to Vest with Player Locaion)

![image](https://user-images.githubusercontent.com/1837913/76307033-5e884380-630b-11ea-9b50-8814e2d42169.png)

##### 4. Content/Maps/Sample.umap : example map with level blueprint

![image](https://user-images.githubusercontent.com/1837913/76305297-4105aa80-6308-11ea-8612-7574a4fbc5c2.png)


### Tested with UE4.22.3

