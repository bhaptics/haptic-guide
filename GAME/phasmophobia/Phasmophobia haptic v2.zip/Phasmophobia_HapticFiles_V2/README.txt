[2D] ; 소리의 크기에 관계없이 진동의 세기가 일정한 경우
NAME			DESCRIPTION
Vest_ElectricalMachineDown	발전기가 다운되었을때



[3D] ; 소리의 크기에 따라 진동의 세기가 다른 경우
NAME			DESCRIPTION
Head_GhostBreath		유령이 플레이어 귓가에 대고 숨쉴때(플레이어가 죽기 직전에 듣는것과 동일)
Head_GhostSound		유령이 으어어어 소리낼 때(첨부한 Head_GhostSound.mp4 참조)

Vest_GhostBreath		Head와 동일
Vest_GhostSound		Head와 동일
Vest_CarHorn		차 경적소리 날 때(루프는 선택)
Vest_EMF		EMF 탐지기로 감지했을때(1~5단계에 따라 Intensity를 다르게)
Vest_UpperImpact		조끼의 위쪽에 간단한 피드백1(recommend. 유령이 대답할때)
Vest_LowerImpact1		조끼의 아래쪽에 간단한 피드백1(recommend. 발소리, 계단소리)
Vest_LowerImpact2		조끼의 아래쪽에 간단한 피드백2(recommend. 발소리, 문 닫힐때)
Vest_LowerImpact3		조끼의 아래쪽에 간단한 피드백3(recommend. 문 열릴때)
Vest_Telephone		전화벨이 울릴때(루프는 선택)
Vest_RadioOn		라디오가 켜졌을때(귀신이 켰을때만 넣어도 좋다, Telephone과 마찬가지로 루프는 선택)