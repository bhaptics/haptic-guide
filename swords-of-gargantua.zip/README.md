[Vest]

- Slash Block
- Low Health Heartbeat
- Death
- Recoil for Weapons
- Crashed Weapon Slashed
- Weapon Runed
- Weapon Slots
- Melee Attacked
- Range Attacked
- Heal Up
- Dash
- Stage Clear



[Arms]

- Shield Block
- Recoil for Weapons
- Crashed Weapon Slashed
- Weapon Runed
- Weapon Equip
- Heal Up



[Head]

- Melee Attacked
- Dash